package com.example.loginandsignup;

import android.view.LayoutInflater;
import android.view.View;

import java.text.BreakIterator;

public class ActivityUploadBinding {
    public int root;
    public View saveButton;
    public BreakIterator uploadName;
    public BreakIterator uploadOperator;
    public BreakIterator uploadLocation;
    public BreakIterator uploadPhone;

    public static ActivityUploadBinding inflate(LayoutInflater layoutInflater) {
        return null;
    }
}
