package com.example.loginandsignup;

import android.view.LayoutInflater;
import android.view.View;

import java.text.BreakIterator;

public class ActivityUpdateBinding {
    public int root;
    public View updateButton;
    public BreakIterator referencePhone;
    public BreakIterator updateName;
    public BreakIterator updateOperator;
    public BreakIterator updateLocation;

    public static ActivityUpdateBinding inflate(LayoutInflater layoutInflater) {
        return null;
    }
}
