package com.example.loginandsignup;

import android.view.LayoutInflater;
import android.view.View;

import java.text.BreakIterator;

public class ActivityDeleteBinding {
    public int root;
    public View deleteButton;
    public BreakIterator deletePhone;

    public static ActivityDeleteBinding inflate(LayoutInflater layoutInflater) {
        return null;
    }
}
