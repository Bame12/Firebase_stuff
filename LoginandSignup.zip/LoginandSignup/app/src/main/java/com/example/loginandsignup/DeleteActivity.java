package com.example.loginandsignup;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DeleteActivity extends AppCompatActivity {

    private ActivityDeleteBinding binding; // View binding for UI interaction
    private DatabaseReference database;   // Reference to Firebase Realtime Database

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDeleteBinding.inflate(getLayoutInflater());
        setContentView(binding.root);

        binding.deleteButton.setOnClickListener(view -> {
            String phone = binding.deletePhone.getText().toString();
            if (!phone.isEmpty()) {
                deleteData(phone);
            } else {
                Toast.makeText(this, "Please enter the phone number", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteData(String phone) {
        database = FirebaseDatabase.getInstance().getReference("Users");
        database.child(phone).removeValue()
                .addOnSuccessListener(unused -> {
                    binding.deletePhone.setText(""); // Clear the input field
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Unable to delete", Toast.LENGTH_SHORT).show();
                });
    }
}