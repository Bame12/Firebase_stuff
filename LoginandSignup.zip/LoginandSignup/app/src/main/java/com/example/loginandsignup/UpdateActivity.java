package com.example.loginandsignup;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class UpdateActivity extends AppCompatActivity {

    private ActivityUpdateBinding binding;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpdateBinding.inflate(getLayoutInflater());
        setContentView(binding.root);

        binding.updateButton.setOnClickListener(view -> {
            String referencePhone = binding.referencePhone.getText().toString();
            String updateName = binding.updateName.getText().toString();
            String updateOperator = binding.updateOperator.getText().toString();
            String updateLocation = binding.updateLocation.getText().toString();

            updateData(referencePhone, updateName, updateOperator, updateLocation);
        });
    }

    private void updateData(String phone, String name, String operator, String location) {

        database = FirebaseDatabase.getInstance().getReference("Users");
        Map<String, String> user = new HashMap<>();
        user.put("name", name);
        user.put("operator", operator);
        user.put("location", location);

        database.child(phone).updateChildren(Collections.unmodifiableMap(user))
                .addOnSuccessListener(unused -> {
                    binding.referencePhone.setText("");
                    binding.updateName.setText("");
                    binding.updateOperator.setText("");
                    binding.updateLocation.setText("");
                    Toast.makeText(this, "Successfully Updated", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to Update", Toast.LENGTH_SHORT).show();
                });
    }
}
