package com.example.loginandsignup;

public class User {
    private String name;
    private String operator;
    private String location;
    private String phone;

    // Constructor
    public User(String name, String operator, String location, String phone) {
        this.name = name;
        this.operator = operator;
        this.location = location;
        this.phone = phone;
    }

    // Getters (Optional, but recommended for accessing data)
    public String getName() {
        return name;
    }

    public String getOperator() {
        return operator;
    }

    public String getLocation() {
        return location;
    }

    public String getPhone() {
        return phone;
    }

    // Setters (Optional, if you need to modify data)
    public void setName(String name) {
        this.name = name;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}