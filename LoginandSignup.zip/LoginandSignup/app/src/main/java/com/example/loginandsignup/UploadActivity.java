package com.example.loginandsignup;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UploadActivity extends AppCompatActivity {

    private ActivityUploadBinding binding;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUploadBinding.inflate(getLayoutInflater());
        setContentView(binding.root);

        binding.saveButton.setOnClickListener(view -> {
            String name = binding.uploadName.getText().toString();
            String operator = binding.uploadOperator.getText().toString();
            String location = binding.uploadLocation.getText().toString();
            String phone = binding.uploadPhone.getText().toString();

            database = FirebaseDatabase.getInstance().getReference("Users");
            User user = new User(name, operator, location, phone);
            database.child(phone).setValue(user)
                    .addOnSuccessListener(unused -> {
                        // Clear input fields
                        binding.uploadName.setText("");
                        binding.uploadOperator.setText("");
                        binding.uploadLocation.setText("");
                        binding.uploadPhone.setText("");

                        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();

                        // Navigate back to MainActivity
                        Intent intent = new Intent(UploadActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish(); // Close the current activity
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
                    });
        });
    }
}