package com.example.loginandsignup;

import android.view.LayoutInflater;
import android.view.View;

public class ActivityMainBinding {
    public int root;
    public View mainUpload;
    public View mainUpdate;
    public View mainDelete;

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater) {
        return null;
    }
}
